# VulkanPy

A Python Vulkan binding generator based on the official Vulkan `vk.xml` registry.

This project generates Python `ctypes` bindings for the Vulkan API, allowing Vulkan applications to be written directly in Python while keeping the API close to the original Vulkan interface.

The generated binding includes Vulkan types, structures, handles, enums, bitmasks, function pointers, and commands, along with dynamic loading and command dispatch.

## Getting Started

Clone the repository and explore the included examples:

```bash
git clone https://github.com/StormMGamming41/Vulkan-vk-xml-to-py-parser.git
cd Vulkan-vk-xml-to-py-parser
```

The repository includes examples demonstrating the binding being used to create actual Vulkan applications, starting from basic initialization and progressing to rendering.

## Documentation

If you're here to learn how to use the binding, start with the documentation:

- ```docs/getting_started.md``` — Getting started with the binding
- ```docs/binding_usage.md``` — Using the generated Vulkan API from Python
- ```docs/vulkan_guide.md``` — Building Vulkan applications from the ground up

The Vulkan guide progresses from Hello Triangle to rendering a 3D cube, while the binding guide focuses specifically on using this project in your own applications.

## Examples

The repository contains complete working examples that can be used alongside the documentation to understand how the binding is used in practice.

### Requirements
- Python 3.x
- Vulkan-capable GPU and driver
- Vulkan SDK recommended
- GLFW for the windowed examples

Install GLFW with:

```bash
pip install glfw
```

## Project Status

This project is under active development. The generated binding is already capable of running real Vulkan applications, but the API and generator may continue to evolve.

### License

See LICENSE.

### Repository

https://github.com/StormMGamming41/Vulkan-vk-xml-to-py-parser